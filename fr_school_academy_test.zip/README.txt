FR School Academy — page de sensibilisation

Fichier : index.html

Pour obtenir un lien public gratuit :
1. Crée un dépôt GitHub et ajoute index.html à la racine.
2. Dans Settings > Pages, choisis le déploiement depuis la branche principale (root).
3. GitHub fournira une URL publique une fois le déploiement terminé.

Cette page affiche seulement un message éducatif. Elle ne collecte aucune donnée et ne pirate aucun compte.
